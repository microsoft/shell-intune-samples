#  Form and Apps Monitoring

## Warning ⚠️

Before launching OCctory with this preset, do note the following shortcuts to exit the application:

- **⌥⌘M** to reach the end of monitoring simulation, and thus simulating that all monitors are installed
- **⌘Q** to exit the app when all monitors are installed (or simulated so)

So basically just use **⌥⌘M**  then **⌘Q** to exit. 

## Slide 1

A web view with an app monitoring view. Octory is in full screen and the navigation view is hidden.  

![Slide1](Slide1.png)